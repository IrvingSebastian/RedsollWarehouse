<?php $__env->startSection('content'); ?>
<section class="banner_main">
    <div id="banner1" class="carousel slide" data-ride="carousel">
        <div class="carousel-item active">
            <div class="container">
                <div class="carousel-caption">
                <div class="text-bg">
                    <h1><?php echo e(__('Panel de Control')); ?></h1>
                    <h2>Redsoll Warehouse</h2>
                </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Readsoll proyecto\RedsollWarehouse\resources\views/home.blade.php ENDPATH**/ ?>