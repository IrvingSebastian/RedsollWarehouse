<?php $__env->startSection('content'); ?>
<section class="banner_main">
    <div id="banner1" class="carousel slide" data-ride="carousel">
        <div class="carousel-item active">
            <div class="container">
                <div class="carousel-caption">
                <div class="text-bg">
                    <h2 style="font-size:50mm">Redsoll</h2>
                    <h3 style="font-size:25mm">Tecnología para todos</h3>
                </div>
                </div>
            </div>
        </div>
    </div>
</section>
<br>

<?php if(Auth::user()->rol == "Administrador"): ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <table class="table table-striped table-hover" style="font-size: small">
                            <thead class="thead">
                                <tr>
                                    <th>ID Pieza</th>
                                    <th>Codigo</th>
                                    <th>Descripcion</th>
                                    <th>Entradas</th>
                                    <th>Salidas</th>
                                    <th>Stock</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($pieza->id); ?></td>
                                    <td><?php echo e($pieza->codigo); ?></td>
                                    <td><?php echo e($pieza->descripcion); ?></td>
                                    <td><?php echo e($pieza->entradas); ?></td>
                                    <td><?php echo e($pieza->salidas); ?></td>
                                    <td><?php echo e($pieza->stock); ?></td>
                                    <td>
                                        <?php if(Auth::user()->rol == "Administrador"): ?>
                                        <form action="<?php echo e(route('piezas.destroy', $pieza->id)); ?>" method="POST">
                                            <a class="btn btn-primary btn-sm" style="font-size: small" href="<?php echo e(route('piezas.show',$pieza->id)); ?>">
                                                <i class="fa fa-fw fa-eye"></i> Mostrar</a>
                                            <a class="btn btn-success btn-sm" style="font-size: small" href="<?php echo e(route('piezas.edit',$pieza->id)); ?>">
                                                <i class="fa fa-fw fa-edit"></i> Editar</a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" style="font-size: small">
                                                <i class="fa fa-fw fa-trash-o"></i> Eliminar</button>
                                        </form>
                                            
                                        <?php else: ?>
                                            <a class="btn btn-primary btn-sm" style="font-size: small" href="<?php echo e(route('piezas.show',$pieza->id)); ?>">
                                                <i class="fa fa-fw fa-eye"></i> Mostrar</a>                                         
                                            <br>    
                                        <?php endif; ?>     
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RedsollWarehouse\resources\views/home.blade.php ENDPATH**/ ?>