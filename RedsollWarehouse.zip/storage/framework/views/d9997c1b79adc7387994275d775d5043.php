<?php $__env->startSection('template_title'); ?>
    <?php echo e(__('Show')); ?> Pieza 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Mostrar')); ?> Pieza</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('piezas.index')); ?>">
                                <i class="fa fa-fw fa-arrow-circle-left"></i> Volver
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="form-group">
                            <strong>Codigo:</strong>
                            <?php echo e($pieza->codigo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Descripcion:</strong>
                            <?php echo e($pieza->descripcion); ?>

                        </div>
                        <div class="form-group">
                            <strong>Entradas:</strong>
                            <?php echo e($pieza->entradas); ?>

                        </div>
                        <div class="form-group">
                            <strong>Salidas:</strong>
                            <?php echo e($pieza->salidas); ?>

                        </div>
                        <div class="form-group">
                            <strong>Stock:</strong>
                            <?php echo e($pieza->stock); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RedsollWarehouse\resources\views/pieza/show.blade.php ENDPATH**/ ?>