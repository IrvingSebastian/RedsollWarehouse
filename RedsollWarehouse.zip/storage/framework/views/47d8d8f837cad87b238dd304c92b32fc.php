<?php $__env->startSection('template_title'); ?>
    Pieza
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                Pieza
                            </span>
                            <div class="float-right">
                                <a href="<?php echo e(route('piezas.index')); ?>" class="btn btn-primary btn-sm mt-2" style="font-size: small">
                                    <i class="fa fa-fw fa-arrow-left"></i> Volver
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" style="font-size: small">
                                <thead class="thead">
                                    <tr>
                                        <th>ID Pieza</th>
                                        <th>Codigo</th>
                                        <th>Descripcion</th>
                                        <th>Entradas</th>
                                        <th>Salidas</th>
                                        <th>Stock</th>
                                        <th>Cantidad Elegida</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($piezas) > 0): ?>
                                    <?php $__currentLoopData = $piezas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pieza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($pieza->id); ?></td>
                                        <td><?php echo e($pieza->codigo); ?></td>
                                        <td><?php echo e($pieza->descripcion); ?></td>
                                        <td><?php echo e($pieza->entradas); ?></td>
                                        <td><?php echo e($pieza->salidas); ?></td>
                                        <td><?php echo e($pieza->stock); ?></td>
                                        <td><?php echo e($cantidades[$key]); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="7">No hay resultados</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <div style="text-align:right">
                                <a href="<?php echo e(route('selector.borrar')); ?>" class="btn btn-danger btn-sm" style="font-size:small">
                                    <i class="fa fa-fw fa-trash-o"></i> Borrar todo lo seleccionado
                                </a>
                                <a href="<?php echo e(route('selector.imprimir')); ?>" class="btn btn-success btn-sm" style="font-size:small">
                                    <i class="fa fa-fw fa-print"></i> Imprimir selección
                                </a>                             
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RedsollWarehouse\resources\views/impresion/seleccion.blade.php ENDPATH**/ ?>