<?php $__env->startSection('template_title'); ?>
    Buscar Piezas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                Pieza
                            </span>

                            <div class="float-right">
                                <form class="mt-2" action="<?php echo e(route('imprimir')); ?>" method="get">
                                    <?php echo csrf_field(); ?>
                                    <a href="<?php echo e(route('piezas.create')); ?>" class="btn btn-primary btn-sm" style="font-size: small">
                                        <i class="fa fa-fw fa-plus"></i> Crear nueva pieza
                                    </a>
                                    <button type="submit" class="btn btn-primary btn-sm" style="font-size: small">
                                        <i class="fa fa-fw fa-print"></i> Imprimir 
                                    </button>
                                </form>
                                <form class="mt-2" action="<?php echo e(route('search')); ?>" method="get">
                                    <?php echo csrf_field(); ?>
                                    <input type="search" class="form-control-sm" placeholder="Buscar" name="texto" value="<?php echo e($texto); ?>" style="font-size: small">            
                                    <button type="submit" class="btn btn-sm btn-success">
                                        <i class="fa fa-fw fa-search"></i> Buscar
                                    </button>
                                </form>
                                <a class="mt-2 btn btn-sm btn-primary" href="<?php echo e(route('piezas.index')); ?>"><i class="fa fa-fw fa-arrow-circle-left"></i> Volver </a>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>ID Pieza</th>
										<th>Codigo</th>
										<th>Descripcion</th>
										<th>Entradas</th>
										<th>Salidas</th>
										<th>Stock</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $piezas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pieza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($pieza->id); ?></td>
        								    <td><?php echo e($pieza->codigo); ?></td>
											<td><?php echo e($pieza->descripcion); ?></td>
											<td><?php echo e($pieza->entradas); ?></td>
											<td><?php echo e($pieza->salidas); ?></td>
											<td><?php echo e($pieza->stock); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('piezas.destroy',$pieza->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('piezas.show',$pieza->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Mostrar')); ?></a>
                                                    <a class="btn btn-sm btn-success" href="<?php echo e(route('piezas.edit',$pieza->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Editar')); ?></a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Eliminar')); ?></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo e($piezas->links('pagination.pagination')); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RedsollWarehouse\resources\views/pieza/search.blade.php ENDPATH**/ ?>